use anchor_lang::prelude::*;
use crate::instructions::*;

pub mod errors;
pub mod instructions;
pub mod states;

declare_id!("F6NKeaoPbchYnbcJZ5YSAqfMcHuP7GLExTuDK3qmgtgW");

#[program]
pub mod spliter {
    use super::*;

    pub fn create_split(
        ctx: Context<instructions::InitializeSplit>,
        reciever: Pubkey,
        total_amount: u64,
        contributors: Vec<states::Spliter>,
    ) -> Result<()> {
        instructions::create_split(ctx, reciever, total_amount, contributors)
    }

    pub fn contribute(ctx: Context<instructions::Contribute>) -> Result<()> {
        instructions::contribute(ctx)
    }

    pub fn release_payment(ctx: Context<instructions::ReleasePayment>) -> Result<()> {
        instructions::release_payment(ctx)
    }
}